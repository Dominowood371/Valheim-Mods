**MOD Description** 

MoArBuIlDs
adds... more .. building things to the game lol

The whole goblin village can now be built
you also can build the iron gate from the crypts now 


---
**Installation**

Download the mod using TMM or manually install it by tossing in BepInEx/plugins folder

---
**Usage**

Recipes should appear in game through normal play. If you are installing this mod on an existing playthrough, you will have to pick up items or re-order you inventory to learn the new recipes.

---
I wanna extend a huge thank you to Jotunn team they are amazing and basically enabled me to make this project :D 

--- 

** Known Issues **
Some objects do not have snap points
they are cloned objects via code they are not custom made objects therefore I will need to work on adding snap point layers to the objects that were cloned


**Changelog**

**v1.0.0**

* initial release 

**v1.0.1** 

gave the 4x4 cloned stone floor from dungeons a stone cost instead of wood

**V1.0.2**
Fixed the drop on destroy for goblin objects giving mats back in plan build mode


**V1.0.3**

missed rib walls drop on destroy 
