**MOD Description** 

Steel Age is a mod that adds some new tiers of crafting to the game to aid you in that portion between right after silver is found. 

This adds a new craftable base material called Steel into the game
It is made by using Iron in a blast forge to then gain a steel ingot as the converted item


There are 6 new weapons that come along with this crafting material:
Steel Battle Axe
Steel War Axe
Steel Battle Hammer
Draugr Steel Sword
Nord Hero Steel Bow
Steel Mace


---
**Installation**

1) Go to [BepInExPack Valheim](https://valheim.thunderstore.io/package/denikson/BepInExPack_Valheim/)
2) Download it and follow the installation manual
3) Drag the unzipped SteelAge folder into -> <Steam Location>\steamapps\common\Valheim\BepInEx\plugin\  

The next time you start your game, the mod will be enabled. To disable it, just remove it from the mods folder.

---
**Usage**

Recipes should appear in game through normal play. If you are installing this mod on an existing playthrough, you will have to pick up items or re-order you inventory to learn the new recipes.

---
I wanna extend a huge thank you to Jotunn team they are amazing and basically enabled me to make this project :D 

--- 
**Changelog**

**v1.0.0**

* initial release 
 
 **V1.0.1**
 Readme changes
 
 **V1.0.2**
 Readme Changes


 **V1.0.3**

Fix Mace not showing 

**V1.0.4**

Fix crafting upgrade cost being free 

**V1.0.5**

Update Dependencies 

**V1.0.6**

Change asset names to avoid conflicts with the testmod example from jotunn

**V1.0.7**

Update dependancy string for JotunnLib  (thunderstore just doesnt do it auotmatically) 
Update NuGet package in Visual studio to reflect new base lib 
Update BepinEx build libs to 5.4.11

**V1.0.8**
Update dependancy strings to align with newest Jotunn their release fixes lots of compatibility problems

**V1.0.9**
Added Steel Arrows
Steel Nordic Sword
Redid some textures/shaders

**V1.0.10**
Sometimes I don't upload things cuz they arent worth uploading you know?

**V1.0.11**
Added Swedish steel sword
Added steel viking axe

Fixed up textures so they aren't dark af anymore
fixed translations for objects so all have a translation now